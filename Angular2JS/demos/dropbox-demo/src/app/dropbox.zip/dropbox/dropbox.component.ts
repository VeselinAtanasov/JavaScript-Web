import { Component, OnInit } from '@angular/core';
require('isomorphic-fetch'); // or another library of choice.
const Dropbox = require('dropbox').Dropbox;
const dbx = new Dropbox({ accessToken: 'bcGGNB1ly_AAAAAAAAAALBb0qN4XJ-ccCbj_AkmRqNihqBytE-XQF0Q2GmweYFzA' });

@Component({
  selector: 'app-dropbox',
  templateUrl: './dropbox.component.html',
  styleUrls: ['./dropbox.component.css']
})
export class DropboxComponent implements OnInit {
  public name2: string;
  public file2;
  public myFile: any;
  constructor() { }

  ngOnInit() {
  }

  fileChanged(event){
    this.myFile = event.target.files[0];
    console.log(this.myFile)
  }

  handleSubmit(data) {
    console.log(data.value)
    // console.log(fileInput);
     let file = this.myFile;
     let fileName= Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15)+'.jpg';

    dbx.filesUpload({
      path: '/vladi/' + fileName,   //file.name,
      contents: file,
      autorename: false,
      mode: 'add'
    })
      .then((response) => {
        console.dir(response)
      })
      .catch(function (error) {
        console.error(error);
      });
  }

}
