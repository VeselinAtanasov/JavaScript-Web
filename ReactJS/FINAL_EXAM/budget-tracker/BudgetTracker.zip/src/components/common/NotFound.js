import React from 'react';

const NotFound = (props) =>(
    <div className="col-sm-12"  >
       <h1>404 NOT FOUND</h1>
    </div>
);

export default NotFound;